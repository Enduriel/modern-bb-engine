// A test mod for ModernEngine.registerFont: a serif Han font for the labels and
// region names, where this engine is the one running.
if ("ModernEngine" in ::getroottable())
{
	::ModernEngine.registerFont("gfx/mod_han_font_test/bb_test_han_serif.otf", {
		For = ["cinzel_bold_20", "cinzel_bold_100"],
		Scripts = "Han"
	});
}
